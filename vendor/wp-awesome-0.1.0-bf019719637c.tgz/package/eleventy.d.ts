/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: eleventy.d.ts
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

/** Public declarations for the eleventy subpath. */
export { createWordPressEleventyPlugin } from './index.js'
