/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: index.js
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

'use strict'

// Keep the public entry point independent of each consuming site's configuration.
module.exports = {
  ...require('./auth'),
  ...require('./content'),
  ...require('./eleventy'),
  ...require('./policies'),
  ...require('./records'),
  ...require('./rest-client'),
  ...require('./routes'),
  ...require('./sanitize'),
  ...require('./styles'),
}
