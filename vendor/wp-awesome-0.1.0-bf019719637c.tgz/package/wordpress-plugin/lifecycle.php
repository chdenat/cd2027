<?php
/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: wordpress-plugin/lifecycle.php
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

defined('ABSPATH') || exit;

/** Owns lifecycle cleanup without loading the publisher or installing its schema. */
final class WPEC_WordPress_Eleventy_Lifecycle {
    const INVENTORY_OPTION = 'wpec_connector_cleanup_inventory';
    const DEFAULT_CRON_HOOK = 'wpec_connector_send_content';
    const SITE_BATCH_SIZE = 100;

    /**
     * Remembers actual cron/cache keys so later configuration changes cannot hide them.
     * The inventory contains names only, never configuration values or credentials.
     *
     * @param string $cron_hook The plugin's configured dispatch hook.
     * @param string[] $transient_keys The plugin's hashed workflow cache keys.
     */
    public static function remember_resources($cron_hook, $transient_keys) {
        $stored = get_option(self::INVENTORY_OPTION, array());
        $inventory = is_array($stored) ? $stored : array();
        $hooks = isset($inventory['cron_hooks']) && is_array($inventory['cron_hooks']) ? $inventory['cron_hooks'] : array();
        $keys = isset($inventory['transient_keys']) && is_array($inventory['transient_keys']) ? $inventory['transient_keys'] : array();
        $hooks[] = $cron_hook;
        $keys = array_merge($keys, $transient_keys);
        $inventory = array(
            'cron_hooks' => array_values(array_unique(array_filter($hooks, array(__CLASS__, 'is_cron_hook')))),
            'transient_keys' => array_values(array_unique(array_filter($keys, array(__CLASS__, 'is_cache_key')))),
        );

        if ($inventory !== $stored) {
            update_option(self::INVENTORY_OPTION, $inventory, false);
        }
    }

    /** Stops scheduled sends while retaining the queue, history, options, and caches. */
    public static function deactivate($network_wide = false) {
        return self::for_each_site(array(__CLASS__, 'clear_site_cron'), $network_wide && is_multisite());
    }

    /** Removes only plugin-owned data from every site sharing the deleted plugin files. */
    public static function uninstall() {
        return self::for_each_site(array(__CLASS__, 'uninstall_site'), is_multisite());
    }

    /** Processes multisite in bounded batches and always restores the caller's blog. */
    private static function for_each_site($callback, $network_wide) {
        if (!$network_wide) {
            return call_user_func($callback);
        }

        $offset = 0;
        do {
            $site_ids = get_sites(array(
                'fields' => 'ids',
                'number' => self::SITE_BATCH_SIZE,
                'offset' => $offset,
                'orderby' => 'id',
                'order' => 'ASC',
            ));
            foreach ($site_ids as $site_id) {
                switch_to_blog((int) $site_id);
                try {
                    if (!call_user_func($callback)) {
                        return false;
                    }
                } finally {
                    restore_current_blog();
                }
            }
            $offset += count($site_ids);
        } while (count($site_ids) === self::SITE_BATCH_SIZE);

        return true;
    }

    /** Accepts only the sanitized hook names the publisher can register. */
    private static function is_cron_hook($hook) {
        return is_string($hook) && $hook !== '' && sanitize_key($hook) === $hook;
    }

    /** Restricts cleanup to the exact workflow-cache namespace and hash format. */
    private static function is_cache_key($key) {
        return is_string($key) && preg_match('/^wpec_runs_[a-f0-9]{32}$/D', $key) === 1;
    }

    /** Clears every event/argument variant for current, default, and remembered hooks. */
    private static function clear_site_cron() {
        $inventory = get_option(self::INVENTORY_OPTION, array());
        $hooks = is_array($inventory) && isset($inventory['cron_hooks']) && is_array($inventory['cron_hooks'])
            ? $inventory['cron_hooks'] : array();
        $hooks[] = self::DEFAULT_CRON_HOOK;
        if (defined('WPEC_CONNECTOR_CRON_HOOK') && is_string(WPEC_CONNECTOR_CRON_HOOK)) {
            $hooks[] = sanitize_key(trim(WPEC_CONNECTOR_CRON_HOOK));
        }

        foreach (array_unique(array_filter($hooks, array(__CLASS__, 'is_cron_hook'))) as $hook) {
            if (wp_unschedule_hook($hook) === false) {
                return false;
            }
        }
        return true;
    }

    /** Deletes the exact owned tables/options/caches; failures leave cleanup retryable. */
    private static function uninstall_site() {
        global $wpdb;

        if (!self::clear_site_cron()) {
            return false;
        }

        $inventory = get_option(self::INVENTORY_OPTION, array());
        $keys = is_array($inventory) && isset($inventory['transient_keys']) && is_array($inventory['transient_keys'])
            ? $inventory['transient_keys'] : array();

        // Escaped LIKE prefixes cover old database caches and orphaned timeout rows.
        $option_names = $wpdb->get_col($wpdb->prepare(
            'SELECT option_name FROM ' . $wpdb->options . ' WHERE option_name LIKE %s OR option_name LIKE %s',
            $wpdb->esc_like('_transient_wpec_runs_') . '%',
            $wpdb->esc_like('_transient_timeout_wpec_runs_') . '%'
        ));
        if (!is_array($option_names) || $wpdb->last_error !== '') {
            return false;
        }
        foreach ($option_names as $name) {
            if (preg_match('/^_transient_(?:timeout_)?(wpec_runs_[a-f0-9]{32})$/D', $name, $matches)) {
                $keys[] = $matches[1];
            }
        }
        foreach (array_unique(array_filter($keys, array(__CLASS__, 'is_cache_key'))) as $key) {
            // The transient API reaches Redis/Memcached; explicit options also remove stale SQL rows.
            if (!delete_transient($key) && get_transient($key) !== false) {
                return false;
            }
            if (!self::delete_owned_option('_transient_' . $key)
                || !self::delete_owned_option('_transient_timeout_' . $key)) {
                return false;
            }
        }

        foreach (array('wpec_content_events', 'wpec_publication_outbox') as $suffix) {
            $table = str_replace('`', '``', $wpdb->prefix . $suffix);
            if ($wpdb->query('DROP TABLE IF EXISTS `' . $table . '`') === false) {
                return false;
            }
        }
        return self::delete_owned_option('wpec_connector_db_version')
            && self::delete_owned_option(self::INVENTORY_OPTION);
    }

    /** Distinguishes an already absent option from an unsuccessful SQL deletion. */
    private static function delete_owned_option($name) {
        return delete_option($name) || get_option($name, null) === null;
    }
}
