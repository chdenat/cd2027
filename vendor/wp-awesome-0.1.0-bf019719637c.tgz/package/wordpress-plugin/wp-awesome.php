<?php
/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: wordpress-plugin/wp-awesome.php
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

/**
 * Plugin Name: WP Awesome
 * Description: Queues public WordPress changes, dispatches Eleventy builds, and manages separate deployment targets.
 * Version: 0.1.0
 * Requires PHP: 7.2
 * Text Domain: wp-awesome
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/lifecycle.php';

/**
 * Captures public WordPress changes, durably queues GitHub notifications, and
 * provides an administrative publishing dashboard.
 */
final class WPEC_WordPress_Eleventy_Connector {
    const DB_VERSION = '2';
    const PAGE_SLUG = 'wpec-connector';
    const EVENT_ACTION = 'wordpress_eleventy_content_event_queued';
    const HISTORY_LIMIT = 100;
    const HISTORY_RETENTION_DAYS = 365;
    const RUNS_PER_WORKFLOW = 10;
    const RUNS_CACHE_SECONDS = 60;
    const OUTBOX_BATCH_SIZE = 100;
    const DEFAULT_CRON_HOOK = 'wpec_connector_send_content';
    const DEFAULT_AUTO_PUBLISH_TARGET = 'staging';
    const MAX_RETRY_DELAY_SECONDS = 21600;

    /** Registers dashboard, dispatcher-event, and administrative request handlers. */
    public static function boot() {
        self::maybe_install_schema();
        self::remember_cleanup_resources();

        add_action('admin_menu', array(__CLASS__, 'register_admin_page'));
        add_action('admin_post_wpec_connector_force_build', array(__CLASS__, 'handle_force_build'));
        add_action('admin_post_wpec_connector_process_pending', array(__CLASS__, 'handle_process_pending'));
        add_action('admin_post_wpec_connector_refresh', array(__CLASS__, 'handle_refresh'));
        add_action(self::EVENT_ACTION, array(__CLASS__, 'record_content_event'), 10, 1);
        add_action(self::cron_hook(), array(__CLASS__, 'process_scheduled_outbox'));
        add_action('init', array(__CLASS__, 'resume_pending_outbox'));

        self::register_content_hooks();
    }

    /** Creates or upgrades the bounded content-change history table. */
    public static function activate() {
        self::install_schema();
        self::remember_cleanup_resources();
    }

    /** Records the configured resources needed for cleanup even after configuration changes. */
    private static function remember_cleanup_resources() {
        $cache_keys = array();
        $credentials = self::github_credentials();
        foreach (self::targets() as $target) {
            if ($credentials['repository_valid'] && $target['valid']) {
                $cache_keys[] = self::workflow_cache_key($credentials, $target);
            }
        }
        WPEC_WordPress_Eleventy_Lifecycle::remember_resources(self::cron_hook(), $cache_keys);
    }

    /** Registers WordPress content changes that can affect generated public pages. */
    private static function register_content_hooks() {
        add_action('wp_after_insert_post', array(__CLASS__, 'queue_post_change'), 20, 4);
        add_action('before_delete_post', array(__CLASS__, 'queue_post_deletion'), 10, 2);
        add_action('woocommerce_new_product', array(__CLASS__, 'queue_product_change'), 100, 1);
        add_action('woocommerce_update_product', array(__CLASS__, 'queue_product_change'), 100, 1);
        add_action('added_post_meta', array(__CLASS__, 'queue_post_meta_change'), 10, 4);
        add_action('updated_post_meta', array(__CLASS__, 'queue_post_meta_change'), 10, 4);
        add_action('deleted_post_meta', array(__CLASS__, 'queue_post_meta_change'), 10, 4);
        add_action('created_term', array(__CLASS__, 'queue_term_change'), 10, 3);
        add_action('edited_term', array(__CLASS__, 'queue_term_change'), 10, 3);
        add_action('delete_term', array(__CLASS__, 'queue_term_deletion'), 10, 5);
        add_action('set_object_terms', array(__CLASS__, 'queue_taxonomy_relation_change'), 10, 6);
        add_action('added_term_meta', array(__CLASS__, 'queue_term_meta_change'), 10, 4);
        add_action('updated_term_meta', array(__CLASS__, 'queue_term_meta_change'), 10, 4);
        add_action('deleted_term_meta', array(__CLASS__, 'queue_term_meta_change'), 10, 4);
        add_action('add_attachment', array(__CLASS__, 'queue_media_change'), 10, 1);
        add_action('attachment_updated', array(__CLASS__, 'queue_media_change'), 10, 1);
        add_action('delete_attachment', array(__CLASS__, 'queue_media_deletion'), 10, 1);
        add_action('wp_update_nav_menu', array(__CLASS__, 'queue_menu_change'), 10, 1);
    }

    /** Queues a public record change and publishes only a metadata-only action event. */
    public static function queue_post_change($post_id, $post, $update, $post_before) {
        if (!$post instanceof WP_Post || wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }

        if ($post->post_type === 'attachment') {
            return;
        }

        $post_type = get_post_type_object($post->post_type);
        $publishable_type = $post_type && ($post_type->public || $post->post_type === 'product' || $post->post_type === 'wp_navigation');
        $was_public = $post_before instanceof WP_Post && $post_before->post_status === 'publish';
        if (!$publishable_type || ($post->post_status !== 'publish' && !$was_public)) {
            return;
        }

        $changed_fields = array();
        if (!$post_before instanceof WP_Post) {
            $changed_fields[] = 'created';
        } else {
            foreach (array(
                'post_title' => 'title',
                'post_content' => 'content',
                'post_excerpt' => 'excerpt',
                'post_status' => 'status',
                'post_name' => 'slug',
                'post_parent' => 'parent',
                'menu_order' => 'order',
            ) as $property => $field) {
                if (isset($post_before->$property, $post->$property) && $post_before->$property !== $post->$property) {
                    $changed_fields[] = $field;
                }
            }
        }

        if ($changed_fields) {
            self::queue_content_event($post->post_type, $post_id, $post->post_status, $changed_fields, $post->post_modified_gmt);
        }
    }

    /** Queues the removal of a previously public post or custom content type. */
    public static function queue_post_deletion($post_id, $post) {
        if (!$post instanceof WP_Post || $post->post_status !== 'publish') {
            return;
        }

        $post_type = get_post_type_object($post->post_type);
        if ($post_type && ($post_type->public || $post->post_type === 'product' || $post->post_type === 'wp_navigation')) {
            self::queue_content_event($post->post_type, $post_id, 'deleted', array('deleted'), gmdate('Y-m-d H:i:s'));
        }
    }

    /** Queues product CRUD changes that may not pass through the ordinary post save hook. */
    public static function queue_product_change($product_id) {
        $post = get_post($product_id);
        if ($post instanceof WP_Post && $post->post_status === 'publish') {
            self::queue_content_event('product', $product_id, 'publish', array('product'), $post->post_modified_gmt);
        }
    }

    /** Queues public post metadata changes without placing metadata values in the event. */
    public static function queue_post_meta_change($meta_id, $object_id, $meta_key, $meta_value) {
        $post = get_post($object_id);
        if (!$post instanceof WP_Post) {
            return;
        }

        if ($post->post_type === 'attachment') {
            if (in_array($meta_key, array('_wp_attachment_metadata', '_wp_attached_file'), true)) {
                self::queue_content_event('media', $object_id, 'publish', array('media_metadata'), $post->post_modified_gmt);
            }
            return;
        }

        if ($post->post_status !== 'publish' || !self::is_publishable_post($post)) {
            return;
        }

        $ignored_keys = array('_edit_lock', '_edit_last', '_wp_old_date', '_encloseme', '_pingme');
        if (in_array($meta_key, $ignored_keys, true) || strpos((string) $meta_key, '_oembed_') === 0 || strpos((string) $meta_key, '_transient_') === 0) {
            return;
        }

        $record_type = $post->post_type === 'product' ? 'product' : $post->post_type;
        self::queue_content_event($record_type, $object_id, 'publish', array('metadata', $meta_key), $post->post_modified_gmt);
    }

    /** Queues changes to terms attached to public taxonomies. */
    public static function queue_term_change($term_id, $term_taxonomy_id, $taxonomy) {
        $taxonomy_object = get_taxonomy($taxonomy);
        if ($taxonomy_object && $taxonomy_object->public) {
            self::queue_content_event('term', $term_id, 'publish', array('taxonomy', $taxonomy), gmdate('Y-m-d H:i:s'));
        }
    }

    /** Queues removal of a term from a public taxonomy. */
    public static function queue_term_deletion($term_id, $term_taxonomy_id, $taxonomy, $deleted_term, $object_ids) {
        $taxonomy_object = get_taxonomy($taxonomy);
        if ($taxonomy_object && $taxonomy_object->public) {
            self::queue_content_event('term', $term_id, 'deleted', array('taxonomy', $taxonomy, 'deleted'), gmdate('Y-m-d H:i:s'));
        }
    }

    /** Queues relationship changes between a public term and a published record. */
    public static function queue_taxonomy_relation_change($object_id, $terms, $term_taxonomy_ids, $taxonomy, $append, $old_term_taxonomy_ids) {
        $taxonomy_object = get_taxonomy($taxonomy);
        $post = get_post($object_id);
        if ($taxonomy_object && $taxonomy_object->public && $post instanceof WP_Post && $post->post_status === 'publish' && self::is_publishable_post($post)) {
            self::queue_content_event('taxonomy_relation', $object_id, 'publish', array('taxonomy_relation', $taxonomy), $post->post_modified_gmt);
        }
    }

    /** Queues metadata changes for terms in public taxonomies. */
    public static function queue_term_meta_change($meta_id, $term_id, $meta_key, $meta_value) {
        $term = get_term($term_id);
        if (!$term || is_wp_error($term)) {
            return;
        }

        $taxonomy_object = get_taxonomy($term->taxonomy);
        if ($taxonomy_object && $taxonomy_object->public) {
            self::queue_content_event('term', $term_id, 'publish', array('taxonomy_meta', $term->taxonomy, $meta_key), gmdate('Y-m-d H:i:s'));
        }
    }

    /** Queues a media record change. */
    public static function queue_media_change($attachment_id) {
        $post = get_post($attachment_id);
        if ($post instanceof WP_Post) {
            self::queue_content_event('media', $attachment_id, 'publish', array('media'), $post->post_modified_gmt);
        }
    }

    /** Queues removal of a media record. */
    public static function queue_media_deletion($attachment_id) {
        self::queue_content_event('media', $attachment_id, 'deleted', array('media', 'deleted'), gmdate('Y-m-d H:i:s'));
    }

    /** Queues a classic navigation menu change. */
    public static function queue_menu_change($menu_id) {
        self::queue_content_event('menu', $menu_id, 'publish', array('menu'), gmdate('Y-m-d H:i:s'));
    }

    /** Queues an event from built-in or consumer-owned content sources. */
    public static function queue_content_event($record_type, $record_id, $status, $changed_fields = array(), $modified_gmt = '') {
        global $wpdb;

        $record_type = sanitize_key((string) $record_type);
        $record_id = absint($record_id);
        if ($record_type === '' || $record_id < 1) {
            return false;
        }

        $safe_fields = array();
        foreach ((array) $changed_fields as $field) {
            if (is_scalar($field)) {
                $field = sanitize_key((string) $field);
                if ($field !== '') {
                    $safe_fields[] = $field;
                }
            }
        }
        $modified_timestamp = is_string($modified_gmt) && $modified_gmt !== '' ? strtotime($modified_gmt) : false;
        $event = array(
            'event_id' => wp_generate_uuid4(),
            'record_type' => $record_type,
            'record_id' => $record_id,
            'status' => sanitize_key((string) $status),
            'changed_fields' => array_values(array_unique($safe_fields)),
            'modified_gmt' => gmdate('Y-m-d H:i:s', $modified_timestamp ?: time()),
        );

        $inserted = $wpdb->insert(
            self::outbox_table_name(),
            array(
                'event_id' => $event['event_id'],
                'record_type' => $event['record_type'],
                'record_id' => $event['record_id'],
                'record_status' => $event['status'],
                'changed_fields' => wp_json_encode($event['changed_fields']),
                'modified_gmt' => $event['modified_gmt'],
                'queued_gmt' => gmdate('Y-m-d H:i:s'),
                'attempts' => 0,
                'next_attempt_gmt' => gmdate('Y-m-d H:i:s'),
            ),
            array('%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s')
        );

        if ($inserted === false) {
            error_log('WP Awesome could not persist a content publication event.');
            return false;
        }

        // Keep the event record durable before notifying audit listeners or scheduling delivery.
        do_action(self::EVENT_ACTION, $event);
        self::schedule_dispatch(5);
        return $event['event_id'];
    }

    /** Returns whether a post type is included in public-site updates. */
    private static function is_publishable_post($post) {
        if (!$post instanceof WP_Post) {
            return false;
        }

        $post_type = get_post_type_object($post->post_type);
        return $post_type && ($post_type->public || $post->post_type === 'product' || $post->post_type === 'wp_navigation');
    }

    /** Registers the connector page under the WordPress Tools menu. */
    public static function register_admin_page() {
        add_management_page(
            __('WP Awesome', 'wp-awesome'),
            __('WP Awesome', 'wp-awesome'),
            'manage_options',
            self::PAGE_SLUG,
            array(__CLASS__, 'render_admin_page')
        );
    }

    /**
     * Saves a compact metadata-only record for a dispatcher event.
     *
     * The event must already be stored in the dispatcher's durable outbox. A
     * dashboard logging failure must never interrupt content publication.
     *
     * @param mixed $event Sanitized event data emitted by the dispatcher.
     */
    public static function record_content_event($event) {
        global $wpdb;

        if (!is_array($event) || empty($event['event_id']) || empty($event['record_type'])) {
            return;
        }

        $event_id = sanitize_text_field((string) $event['event_id']);
        $record_type = sanitize_key((string) $event['record_type']);
        if ($event_id === '' || $record_type === '') {
            return;
        }

        $record_id = isset($event['record_id']) ? absint($event['record_id']) : 0;
        $fields = isset($event['changed_fields']) && is_array($event['changed_fields'])
            ? array_values(array_unique(array_map('sanitize_key', $event['changed_fields'])))
            : array();
        $modified_timestamp = isset($event['modified_gmt']) ? strtotime((string) $event['modified_gmt']) : false;
        $modified_gmt = gmdate('Y-m-d H:i:s', $modified_timestamp ?: time());
        $queued_gmt = current_time('mysql', true);

        $inserted = $wpdb->replace(
            self::table_name(),
            array(
                'event_id' => $event_id,
                'record_type' => $record_type,
                'record_id' => $record_id,
                'record_status' => isset($event['status']) ? sanitize_key((string) $event['status']) : '',
                'record_title' => self::record_title($record_type, $record_id),
                'changed_fields' => wp_json_encode($fields),
                'modified_gmt' => $modified_gmt,
                'queued_gmt' => $queued_gmt,
            ),
            array('%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s')
        );

        if ($inserted === false) {
            error_log('WP Awesome could not record a queued content event.');
            return;
        }

        // Keep the admin audit trail bounded without changing the dispatcher's outbox.
        $cutoff = gmdate('Y-m-d H:i:s', time() - (self::HISTORY_RETENTION_DAYS * DAY_IN_SECONDS));
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::table_name() . ' WHERE queued_gmt < %s', $cutoff));
    }

    /** Renders configuration diagnostics, content-change history, and target build runs. */
    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to view this page.', 'wp-awesome'));
        }

        $credentials = self::github_credentials();
        $targets = self::targets();
        $runs_by_target = array();
        foreach ($targets as $target_id => $target) {
            $runs_by_target[$target_id] = $target['valid']
                ? self::workflow_runs($credentials, $target)
                : array('ok' => false, 'message' => __('Configuration de cible incomplète.', 'wp-awesome'), 'runs' => array());
        }

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('WP Awesome', 'wp-awesome') . '</h1>';
        echo '<p>' . esc_html__('Vérifiez les connexions, suivez les modifications mises en file et consultez les résultats GitHub Actions. Une demande acceptée par GitHub ne signifie pas encore que le build a réussi.', 'wp-awesome') . '</p>';

        self::render_admin_notice();
        self::render_configuration_table($credentials, $targets);
        self::render_targets_table($credentials, $targets, $runs_by_target);
        self::render_changes_table();
        self::render_outbox_controls();
        self::render_refresh_form();
        echo '</div>';
    }

    /** Handles a nonce-protected, administrator-only build request for one configured target. */
    public static function handle_force_build() {
        self::require_admin();
        $target_id = isset($_POST['target']) ? sanitize_key(wp_unslash($_POST['target'])) : '';
        check_admin_referer('wpec_connector_force_build_' . $target_id);

        $targets = self::targets();
        if (!isset($targets[$target_id]) || !$targets[$target_id]['valid'] || !$targets[$target_id]['enabled']) {
            self::redirect_with_notice('target_unavailable');
        }

        $credentials = self::github_credentials();
        if (!$credentials['repository_valid'] || $credentials['token'] === '') {
            self::redirect_with_notice('github_config_missing');
        }

        $repo_parts = explode('/', $credentials['repository'], 2);
        $url = self::repository_api_url($repo_parts) . '/dispatches';
        $response = self::github_request('POST', $url, $credentials['token'], array(
            'event_type' => $targets[$target_id]['event_type'],
            'client_payload' => array(
                'target' => $target_id,
                'source' => 'wordpress-admin',
                'requested_at' => gmdate(DATE_ATOM),
            ),
        ));

        if (is_wp_error($response)) {
            self::redirect_with_notice('github_unreachable');
        }

        $status = wp_remote_retrieve_response_code($response);
        if ($status === 204) {
            self::clear_workflow_cache($credentials, $targets[$target_id]);
            self::redirect_with_notice('build_queued');
        }

        self::redirect_with_notice($status === 403 ? 'github_dispatch_forbidden' : 'github_dispatch_failed');
    }

    /** Runs one bounded outbox batch after a nonce-protected administrator request. */
    public static function handle_process_pending() {
        self::require_admin();
        check_admin_referer('wpec_connector_process_pending');

        self::process_outbox(true);
        self::redirect_with_notice(self::pending_count() > 0 ? 'pending_dispatch_attempted' : 'pending_dispatch_complete');
    }

    /** Processes a bounded batch when WordPress cron runs the configured hook. */
    public static function process_scheduled_outbox() {
        self::process_outbox(false);
    }

    /** Reschedules pending work if WP-Cron missed or lost its single event. */
    public static function resume_pending_outbox() {
        if (self::pending_count() > 0 && !wp_next_scheduled(self::cron_hook())) {
            self::schedule_next_dispatch();
        }
    }

    /** Invalidates cached run lists so the dashboard can request a fresh GitHub response. */
    public static function handle_refresh() {
        self::require_admin();
        check_admin_referer('wpec_connector_refresh');

        $credentials = self::github_credentials();
        foreach (self::targets() as $target) {
            if ($target['valid']) {
                self::clear_workflow_cache($credentials, $target);
            }
        }

        self::redirect_with_notice('status_refreshed');
    }

    /** Returns the WordPress database table used for the connector's audit history. */
    private static function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wpec_content_events';
    }

    /** Returns the package-owned durable publication outbox table. */
    private static function outbox_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wpec_publication_outbox';
    }

    /** Returns the configured single-event cron hook, with a package default. */
    private static function cron_hook() {
        $hook = self::configured_constant(array('WPEC_CONNECTOR_CRON_HOOK'));
        $hook = $hook !== '' ? sanitize_key($hook) : '';
        return $hook !== '' ? $hook : self::DEFAULT_CRON_HOOK;
    }

    /** Returns the number of durable notifications that GitHub has not accepted. */
    private static function pending_count() {
        global $wpdb;
        return (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . self::outbox_table_name());
    }

    /** Schedules delivery, moving a later retry forward when fresh work arrives. */
    private static function schedule_dispatch($delay) {
        $hook = self::cron_hook();
        $requested_at = time() + max(1, (int) $delay);
        $scheduled_at = wp_next_scheduled($hook);

        if ($scheduled_at && $scheduled_at <= $requested_at) {
            return;
        }
        if ($scheduled_at) {
            wp_unschedule_event($scheduled_at, $hook);
        }
        wp_schedule_single_event($requested_at, $hook);
    }

    /** Schedules the earliest queued event, or removes an obsolete cron event. */
    private static function schedule_next_dispatch() {
        global $wpdb;
        $next_attempt = $wpdb->get_var('SELECT MIN(next_attempt_gmt) FROM ' . self::outbox_table_name());

        if (!$next_attempt) {
            $scheduled_at = wp_next_scheduled(self::cron_hook());
            if ($scheduled_at) {
                wp_unschedule_event($scheduled_at, self::cron_hook());
            }
            return;
        }

        $next_timestamp = strtotime($next_attempt . ' UTC');
        self::schedule_dispatch(max(1, ($next_timestamp ?: time()) - time()));
    }

    /** Sends one bounded batch to the configured staging workflow. */
    private static function process_outbox($ignore_retry_delay = false) {
        global $wpdb;

        if (self::pending_count() === 0) {
            return true;
        }

        $credentials = self::github_credentials();
        $targets = self::targets();
        $target = isset($targets[self::DEFAULT_AUTO_PUBLISH_TARGET]) ? $targets[self::DEFAULT_AUTO_PUBLISH_TARGET] : null;
        if (!$credentials['repository_valid'] || $credentials['token'] === '' || !$target || !$target['valid'] || !$target['enabled']) {
            error_log('WP Awesome has pending publication events but its GitHub staging configuration is incomplete.');
            self::schedule_dispatch(300);
            return false;
        }

        $now = gmdate('Y-m-d H:i:s');
        $query = $ignore_retry_delay
            ? $wpdb->prepare(
                'SELECT event_id FROM ' . self::outbox_table_name() . ' ORDER BY queued_gmt ASC LIMIT %d',
                self::OUTBOX_BATCH_SIZE
            )
            : $wpdb->prepare(
                'SELECT event_id FROM ' . self::outbox_table_name() . ' WHERE next_attempt_gmt <= %s ORDER BY queued_gmt ASC LIMIT %d',
                $now,
                self::OUTBOX_BATCH_SIZE
            );
        $rows = $wpdb->get_results($query, ARRAY_A);

        if (!$rows) {
            self::schedule_next_dispatch();
            return false;
        }

        $event_ids = array();
        foreach ($rows as $row) {
            if (isset($row['event_id'])) {
                $event_ids[] = sanitize_text_field($row['event_id']);
            }
        }
        if (!$event_ids) {
            self::schedule_dispatch(60);
            return false;
        }

        $repo_parts = explode('/', $credentials['repository'], 2);
        $url = self::repository_api_url($repo_parts) . '/dispatches';
        $response = self::github_request('POST', $url, $credentials['token'], array(
            'event_type' => $target['event_type'],
            'client_payload' => array(
                'target' => self::DEFAULT_AUTO_PUBLISH_TARGET,
                'source' => 'wp-awesome',
                'batch_id' => $event_ids[0],
                'event_count' => count($event_ids),
                'requested_at' => gmdate(DATE_ATOM),
            ),
        ));

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 204) {
            foreach ($event_ids as $event_id) {
                $wpdb->delete(self::outbox_table_name(), array('event_id' => $event_id), array('%s'));
            }
            self::clear_workflow_cache($credentials, $target);
            self::schedule_next_dispatch();
            return true;
        }

        self::retry_outbox_events($event_ids);
        self::schedule_next_dispatch();
        return false;
    }

    /** Retains failed events and applies capped exponential retry delays. */
    private static function retry_outbox_events($event_ids) {
        global $wpdb;
        $table = self::outbox_table_name();

        foreach ($event_ids as $event_id) {
            $attempts = (int) $wpdb->get_var($wpdb->prepare(
                'SELECT attempts FROM ' . $table . ' WHERE event_id = %s',
                $event_id
            )) + 1;
            $delay = self::retry_delay($attempts);
            $wpdb->update(
                $table,
                array(
                    'attempts' => $attempts,
                    'next_attempt_gmt' => gmdate('Y-m-d H:i:s', time() + $delay),
                ),
                array('event_id' => $event_id),
                array('%d', '%s'),
                array('%s')
            );
        }

        error_log('WP Awesome could not dispatch a publication batch to GitHub; the events remain queued for retry.');
    }

    /** Computes exponential retry delay with a strict six-hour upper bound. */
    private static function retry_delay($attempts) {
        return min(self::MAX_RETRY_DELAY_SECONDS, 15 * (2 ** min(11, max(1, (int) $attempts))));
    }

    /** Installs the package-owned audit table when the schema version changes. */
    private static function maybe_install_schema() {
        if (get_option('wpec_connector_db_version') !== self::DB_VERSION) {
            self::install_schema();
        }
    }

    /** Creates the audit history and durable publication queue tables. */
    private static function install_schema() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table_name();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            event_id varchar(64) NOT NULL,
            record_type varchar(64) NOT NULL,
            record_id bigint(20) unsigned NOT NULL DEFAULT 0,
            record_status varchar(32) NOT NULL DEFAULT '',
            record_title text NOT NULL,
            changed_fields text NOT NULL,
            modified_gmt datetime NOT NULL,
            queued_gmt datetime NOT NULL,
            PRIMARY KEY  (event_id),
            KEY queued_gmt (queued_gmt),
            KEY record_lookup (record_type, record_id)
        ) {$charset};";

        dbDelta($sql);

        $outbox = self::outbox_table_name();
        $outbox_sql = "CREATE TABLE {$outbox} (
            event_id varchar(64) NOT NULL,
            record_type varchar(64) NOT NULL,
            record_id bigint(20) unsigned NOT NULL DEFAULT 0,
            record_status varchar(32) NOT NULL DEFAULT '',
            changed_fields text NOT NULL,
            modified_gmt datetime NOT NULL,
            queued_gmt datetime NOT NULL,
            attempts int(10) unsigned NOT NULL DEFAULT 0,
            next_attempt_gmt datetime NOT NULL,
            PRIMARY KEY  (event_id),
            KEY due_events (next_attempt_gmt, queued_gmt)
        ) {$charset};";

        dbDelta($outbox_sql);
        update_option('wpec_connector_db_version', self::DB_VERSION, false);
    }

    /** Returns validated GitHub repository and token configuration without exposing the token. */
    private static function github_credentials() {
        $token = self::configured_constant(array('WPEC_CONNECTOR_GITHUB_TOKEN'));
        $repository = self::configured_constant(array('WPEC_CONNECTOR_REPOSITORY'));
        $repository_valid = (bool) preg_match('/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/', $repository);

        return array(
            'token' => $token,
            'repository' => $repository,
            'repository_valid' => $repository_valid,
        );
    }

    /** Reads the first non-empty server-side constant from a compatibility list. */
    private static function configured_constant($names) {
        foreach ($names as $name) {
            if (defined($name) && is_string(constant($name)) && constant($name) !== '') {
                return trim(constant($name));
            }
        }
        return '';
    }

    /** Returns normalized staging and production target records from wp-config.php. */
    private static function targets() {
        $configured = defined('WPEC_CONNECTOR_TARGETS') && is_array(WPEC_CONNECTOR_TARGETS)
            ? WPEC_CONNECTOR_TARGETS
            : array();
        $targets = array();

        foreach (array('staging', 'production') as $target_id) {
            $raw = isset($configured[$target_id]) && is_array($configured[$target_id]) ? $configured[$target_id] : array();
            $site_url = isset($raw['site_url']) ? esc_url_raw(trim((string) $raw['site_url'])) : '';
            $workflow = isset($raw['workflow']) ? trim((string) $raw['workflow']) : '';
            $event_type = isset($raw['event_type']) ? trim((string) $raw['event_type']) : '';
            $label = isset($raw['label']) ? sanitize_text_field((string) $raw['label']) : ucfirst($target_id);
            $valid_url = self::is_https_url($site_url);
            $valid_workflow = (bool) preg_match('/^[A-Za-z0-9_.-]+\.ya?ml$/', $workflow);
            $valid_event = (bool) preg_match('/^[A-Za-z0-9_-]{1,100}$/', $event_type);
            $configured_target = !empty($raw);

            $targets[$target_id] = array(
                'id' => $target_id,
                'label' => $label,
                'site_url' => $site_url,
                'workflow' => $workflow,
                'event_type' => $event_type,
                'enabled' => isset($raw['enabled']) && in_array($raw['enabled'], array(true, 1, '1', 'true'), true),
                'configured' => $configured_target,
                'valid' => $configured_target && $valid_url && $valid_workflow && $valid_event,
            );
        }

        return $targets;
    }

    /** Checks that a configured origin is absolute HTTPS and has a host. */
    private static function is_https_url($url) {
        $parts = wp_parse_url($url);
        return is_array($parts)
            && isset($parts['scheme'], $parts['host'])
            && strtolower($parts['scheme']) === 'https'
            && $parts['host'] !== ''
            && !isset($parts['user'])
            && !isset($parts['pass']);
    }

    /** Resolves a content identifier to a short editorial label for the admin history. */
    private static function record_title($record_type, $record_id) {
        if ($record_type === 'menu' && function_exists('wp_get_nav_menu_object')) {
            $menu = wp_get_nav_menu_object($record_id);
            if (is_object($menu) && !empty($menu->name)) {
                return sanitize_text_field($menu->name);
            }
        }

        if ($record_type === 'term') {
            $term = get_term($record_id);
            if ($term && !is_wp_error($term) && !empty($term->name)) {
                return sanitize_text_field($term->name);
            }
        }

        $post = get_post($record_id);
        if ($post instanceof WP_Post) {
            $title = get_the_title($post);
            if ($title !== '') {
                return sanitize_text_field(wp_strip_all_tags($title));
            }
        }

        return sprintf(
            /* translators: %1$s is a WordPress record type; %2$d is its identifier. */
            __('Unavailable %1$s #%2$d', 'wp-awesome'),
            $record_type,
            $record_id
        );
    }

    /** Builds the configuration rows shown in the admin dashboard. */
    private static function render_configuration_table($credentials, $targets) {
        $pending_count = self::pending_count();
        $cron_hook = self::cron_hook();
        $next_cron = $cron_hook !== '' ? wp_next_scheduled($cron_hook) : false;

        echo '<h2>' . esc_html__('Vérification de la configuration', 'wp-awesome') . '</h2>';
        echo '<table class="widefat striped"><tbody>';
        self::render_check_row(
            __('Dépôt GitHub', 'wp-awesome'),
            $credentials['repository_valid'],
            $credentials['repository_valid'] ? $credentials['repository'] : __('Non configuré ou format owner/repository invalide', 'wp-awesome')
        );
        self::render_check_row(
            __('Jeton GitHub côté serveur', 'wp-awesome'),
            $credentials['token'] !== '',
            $credentials['token'] !== '' ? __('Présent ; sa valeur est masquée', 'wp-awesome') : __('Absent de wp-config.php', 'wp-awesome')
        );
        self::render_check_row(
            __('URL de l’API REST WordPress', 'wp-awesome'),
            rest_url() !== '',
            rest_url() !== '' ? rest_url() : __('URL REST indisponible', 'wp-awesome')
        );

        if ($pending_count > 0 && !$next_cron) {
            self::render_check_row(
                __('File de publication', 'wp-awesome'),
                false,
                sprintf(__('%d modification(s) en attente ; aucun événement WP-Cron planifié.', 'wp-awesome'), $pending_count)
            );
        } else {
            self::render_check_row(
                __('File de publication', 'wp-awesome'),
                true,
                sprintf(__('%d modification(s) en attente ; cron : %s.', 'wp-awesome'), $pending_count, $cron_hook)
            );
        }

        foreach ($targets as $target) {
            $ready = $target['valid'] && $target['enabled'] && $credentials['repository_valid'] && $credentials['token'] !== '';
            if (!$target['configured']) {
                $description = __('Cible non configurée dans WPEC_CONNECTOR_TARGETS.', 'wp-awesome');
            } elseif (!$target['valid']) {
                $description = __('URL HTTPS, nom de workflow ou event_type invalide.', 'wp-awesome');
            } elseif (!$target['enabled']) {
                $description = __('Configuration présente, mais déclenchement désactivé.', 'wp-awesome');
            } else {
                $description = $target['site_url'] . ' — ' . $target['workflow'] . ' — ' . $target['event_type'];
            }
            self::render_check_row($target['label'], $ready, $description);
        }

        echo '</tbody></table>';
        echo '<p class="description">' . esc_html__('Cette page vérifie la configuration WordPress et l’accès aux exécutions GitHub. Elle ne peut pas lire les secrets des environnements GitHub ni confirmer le routage Apache/Nginx ; vérifiez ces éléments dans Settings → Environments et auprès de l’hébergeur.', 'wp-awesome') . '</p>';
    }

    /** Prints one escaped diagnostic row. */
    private static function render_check_row($label, $ok, $detail) {
        $status = $ok ? __('OK', 'wp-awesome') : __('À vérifier', 'wp-awesome');
        $class = $ok ? 'notice-success' : 'notice-warning';
        echo '<tr><th scope="row">' . esc_html($label) . '</th><td><span class="' . esc_attr($class) . '"><strong>' . esc_html($status) . '</strong></span> — ' . esc_html($detail) . '</td></tr>';
    }

    /** Renders each deployment target and its latest GitHub Actions runs. */
    private static function render_targets_table($credentials, $targets, $runs_by_target) {
        echo '<h2>' . esc_html__('Cibles et résultats des builds', 'wp-awesome') . '</h2>';
        echo '<p>' . esc_html__('Les publications automatiques restent dirigées vers le staging. La production ne démarre qu’après une demande explicite et l’approbation de son environnement GitHub.', 'wp-awesome') . '</p>';

        foreach ($targets as $target_id => $target) {
            echo '<h3>' . esc_html($target['label']) . '</h3>';
            if ($target['site_url'] !== '') {
                echo '<p><code>' . esc_html($target['site_url']) . '</code></p>';
            }

            $can_dispatch = $target['valid'] && $target['enabled'] && $credentials['repository_valid'] && $credentials['token'] !== '';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            echo '<input type="hidden" name="action" value="wpec_connector_force_build">';
            echo '<input type="hidden" name="target" value="' . esc_attr($target_id) . '">';
            wp_nonce_field('wpec_connector_force_build_' . $target_id);
            submit_button(
                sprintf(__('Forcer un build %s', 'wp-awesome'), strtolower($target['label'])),
                'secondary',
                'submit',
                false,
                $can_dispatch ? array() : array('disabled' => 'disabled')
            );
            if (!$can_dispatch) {
                echo '<span class="description">' . esc_html__('Activez cette cible uniquement après avoir vérifié son environnement GitHub, son dossier de déploiement et le routage du domaine.', 'wp-awesome') . '</span>';
            }
            echo '</form>';

            $runs = isset($runs_by_target[$target_id]) ? $runs_by_target[$target_id] : array('ok' => false, 'message' => '', 'runs' => array());
            if (!$target['valid']) {
                echo '<p>' . esc_html__('Workflow non configuré.', 'wp-awesome') . '</p>';
                continue;
            }
            if (!$runs['ok']) {
                echo '<p class="notice notice-warning inline">' . esc_html($runs['message']) . '</p>';
                continue;
            }
            if (!$runs['runs']) {
                echo '<p>' . esc_html__('Aucune exécution trouvée pour ce workflow.', 'wp-awesome') . '</p>';
                continue;
            }

            echo '<table class="widefat striped"><thead><tr>';
            foreach (array('Exécution', 'Branche / commit', 'État', 'Résultat', 'Démarré', 'Journal GitHub') as $heading) {
                echo '<th scope="col">' . esc_html($heading) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ($runs['runs'] as $run) {
                $commit = $run['head_sha'] !== '' ? substr($run['head_sha'], 0, 8) : '—';
                $branch = $run['head_branch'] !== '' ? $run['head_branch'] : '—';
                $started = self::format_github_date($run['run_started_at'] !== '' ? $run['run_started_at'] : $run['created_at']);
                echo '<tr>';
                echo '<td>' . esc_html($run['display_title']) . '</td>';
                echo '<td><code>' . esc_html($branch . ' / ' . $commit) . '</code></td>';
                echo '<td>' . esc_html($run['status']) . '</td>';
                echo '<td>' . esc_html($run['conclusion'] !== '' ? $run['conclusion'] : '—') . '</td>';
                echo '<td>' . esc_html($started) . '</td>';
                echo '<td>';
                if ($run['html_url'] !== '') {
                    echo '<a href="' . esc_url($run['html_url']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Ouvrir', 'wp-awesome') . '</a>';
                } else {
                    echo '—';
                }
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        }
    }

    /** Renders the recent metadata-only WordPress change history. */
    private static function render_changes_table() {
        $changes = self::recent_changes();
        echo '<h2>' . esc_html__('Modifications WordPress envoyées au pipeline', 'wp-awesome') . '</h2>';
        echo '<p>' . esc_html__('WP Awesome enregistre ces événements dans sa file durable avant de notifier GitHub. Les valeurs des contenus ne sont pas enregistrées ici ; seules les références et les champs modifiés sont conservés.', 'wp-awesome') . '</p>';
        if (!$changes) {
            echo '<p>' . esc_html__('Aucune modification publique détectée pour le moment.', 'wp-awesome') . '</p>';
            return;
        }

        echo '<table class="widefat striped"><thead><tr>';
        foreach (array('Date', 'Contenu', 'Type / statut', 'Champs modifiés', 'Événement') as $heading) {
            echo '<th scope="col">' . esc_html($heading) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach ($changes as $change) {
            $fields = json_decode($change['changed_fields'], true);
            $field_label = is_array($fields) && $fields ? implode(', ', array_map('sanitize_text_field', $fields)) : '—';
            $title = $change['record_title'] !== '' ? $change['record_title'] : sprintf('%s #%d', $change['record_type'], $change['record_id']);
            echo '<tr>';
            echo '<td>' . esc_html(get_date_from_gmt($change['queued_gmt'], get_option('date_format') . ' ' . get_option('time_format'))) . '</td>';
            echo '<td>' . esc_html($title) . ' <code>#' . esc_html((string) $change['record_id']) . '</code></td>';
            echo '<td>' . esc_html($change['record_type'] . ' / ' . $change['record_status']) . '</td>';
            echo '<td>' . esc_html($field_label) . '</td>';
            echo '<td><code>' . esc_html($change['event_id']) . '</code></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    /** Renders an administrator action to retry one bounded batch immediately. */
    private static function render_outbox_controls() {
        $pending = self::pending_count();
        echo '<h2>' . esc_html__('File de publication', 'wp-awesome') . '</h2>';
        echo '<p>' . esc_html(sprintf(__('La file contient %d événement(s). Les envois automatiques ciblent le staging ; chaque build récupère le contenu canonique dans WordPress.', 'wp-awesome'), $pending)) . '</p>';

        if ($pending === 0) {
            return;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="wpec_connector_process_pending">';
        wp_nonce_field('wpec_connector_process_pending');
        submit_button(__('Traiter un lot en attente maintenant', 'wp-awesome'), 'secondary', 'submit', false);
        echo '</form>';
    }

    /** Queries the latest connector history rows without loading WordPress content values. */
    private static function recent_changes() {
        global $wpdb;
        $limit = (int) self::HISTORY_LIMIT;
        $table = self::table_name();
        return $wpdb->get_results("SELECT event_id, record_type, record_id, record_status, record_title, changed_fields, queued_gmt FROM {$table} ORDER BY queued_gmt DESC LIMIT {$limit}", ARRAY_A);
    }

    /** Renders the nonce-protected run-list refresh action. */
    private static function render_refresh_form() {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="wpec_connector_refresh">';
        wp_nonce_field('wpec_connector_refresh');
        submit_button(__('Actualiser les résultats GitHub', 'wp-awesome'), 'secondary', 'submit', false);
        echo '</form>';
    }

    /** Fetches and caches the most recent runs for one explicitly configured workflow. */
    private static function workflow_runs($credentials, $target) {
        if (!$credentials['repository_valid']) {
            return array('ok' => false, 'message' => __('Le dépôt GitHub n’est pas configuré.', 'wp-awesome'), 'runs' => array());
        }

        $cache_key = self::workflow_cache_key($credentials, $target);
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return $cached;
        }

        $repo_parts = explode('/', $credentials['repository'], 2);
        $url = self::repository_api_url($repo_parts)
            . '/actions/workflows/' . rawurlencode($target['workflow'])
            . '/runs?per_page=' . self::RUNS_PER_WORKFLOW;
        $response = self::github_request('GET', $url, $credentials['token']);

        if (is_wp_error($response)) {
            $result = array('ok' => false, 'message' => __('WordPress ne parvient pas à joindre l’API GitHub.', 'wp-awesome'), 'runs' => array());
            set_transient($cache_key, $result, 20);
            return $result;
        }

        $status = wp_remote_retrieve_response_code($response);
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        if ($status !== 200 || !is_array($payload) || !isset($payload['workflow_runs']) || !is_array($payload['workflow_runs'])) {
            if ($status === 403) {
                $message = __('GitHub refuse la lecture des exécutions. Pour un dépôt privé, le jeton doit avoir Actions: Read.', 'wp-awesome');
            } elseif ($status === 404) {
                $message = __('Workflow absent du dépôt ou inaccessible avec ce jeton.', 'wp-awesome');
            } else {
                $message = sprintf(__('Lecture GitHub impossible (HTTP %d).', 'wp-awesome'), $status);
            }
            $result = array('ok' => false, 'message' => $message, 'runs' => array());
            set_transient($cache_key, $result, 20);
            return $result;
        }

        $runs = array();
        foreach ($payload['workflow_runs'] as $run) {
            if (!is_array($run)) {
                continue;
            }
            $html_url = isset($run['html_url']) ? esc_url_raw($run['html_url']) : '';
            if ($html_url !== '' && wp_parse_url($html_url, PHP_URL_HOST) !== 'github.com') {
                $html_url = '';
            }
            $runs[] = array(
                'display_title' => isset($run['display_title']) ? sanitize_text_field($run['display_title']) : __('Exécution GitHub Actions', 'wp-awesome'),
                'head_branch' => isset($run['head_branch']) ? sanitize_text_field($run['head_branch']) : '',
                'head_sha' => isset($run['head_sha']) ? sanitize_text_field($run['head_sha']) : '',
                'status' => isset($run['status']) ? sanitize_key($run['status']) : '',
                'conclusion' => isset($run['conclusion']) && $run['conclusion'] !== null ? sanitize_key($run['conclusion']) : '',
                'run_started_at' => isset($run['run_started_at']) ? sanitize_text_field($run['run_started_at']) : '',
                'created_at' => isset($run['created_at']) ? sanitize_text_field($run['created_at']) : '',
                'html_url' => $html_url,
            );
        }

        $result = array('ok' => true, 'message' => '', 'runs' => $runs);
        set_transient($cache_key, $result, self::RUNS_CACHE_SECONDS);
        return $result;
    }

    /** Sends one fixed GitHub REST request with bounded timeouts and no redirects. */
    private static function github_request($method, $url, $token, $body = null) {
        $headers = array(
            'Accept' => 'application/vnd.github+json',
            'User-Agent' => 'wp-awesome-connector',
            'X-GitHub-Api-Version' => '2022-11-28',
        );
        if ($token !== '') {
            $headers['Authorization'] = 'Bearer ' . $token;
        }

        $args = array(
            'method' => $method,
            'timeout' => 15,
            'redirection' => 0,
            'headers' => $headers,
        );
        if ($body !== null) {
            $encoded = wp_json_encode($body);
            if (!is_string($encoded)) {
                return new WP_Error('wpec_json_encode_failed', 'The GitHub request could not be encoded.');
            }
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = $encoded;
        }

        return wp_remote_request($url, $args);
    }

    /** Returns a fixed API origin assembled only from a validated owner/repository pair. */
    private static function repository_api_url($repo_parts) {
        return 'https://api.github.com/repos/' . rawurlencode($repo_parts[0]) . '/' . rawurlencode($repo_parts[1]);
    }

    /** Invalidates the short-lived cache for one target workflow. */
    private static function clear_workflow_cache($credentials, $target) {
        delete_transient(self::workflow_cache_key($credentials, $target));
    }

    /** Creates a stable transient key for one repository and workflow. */
    private static function workflow_cache_key($credentials, $target) {
        return 'wpec_runs_' . md5($credentials['repository'] . '|' . $target['workflow']);
    }

    /** Renders a safe notice code returned after an administrator action. */
    private static function render_admin_notice() {
        if (!isset($_GET['wpec_notice'])) {
            return;
        }

        $notice = sanitize_key(wp_unslash($_GET['wpec_notice']));
        $messages = array(
            'build_queued' => array(true, __('GitHub a accepté la demande ; le résultat apparaîtra dans les exécutions ci-dessous.', 'wp-awesome')),
            'pending_dispatch_complete' => array(true, __('La file de publication est vide.', 'wp-awesome')),
            'pending_dispatch_attempted' => array(true, __('Un lot a été traité ou replanifié. Consultez le compteur et les dernières exécutions GitHub.', 'wp-awesome')),
            'status_refreshed' => array(true, __('Les résultats GitHub ont été actualisés.', 'wp-awesome')),
            'target_unavailable' => array(false, __('Cette cible est désactivée ou sa configuration est incomplète.', 'wp-awesome')),
            'github_config_missing' => array(false, __('Le dépôt ou le jeton GitHub est absent ou invalide.', 'wp-awesome')),
            'github_unreachable' => array(false, __('WordPress ne parvient pas à contacter l’API GitHub.', 'wp-awesome')),
            'github_dispatch_forbidden' => array(false, __('GitHub a refusé le déclenchement. Vérifiez la permission Contents: Write du jeton.', 'wp-awesome')),
            'github_dispatch_failed' => array(false, __('GitHub n’a pas accepté la demande de build. Consultez la configuration du dépôt et du workflow.', 'wp-awesome')),
        );
        if (!isset($messages[$notice])) {
            return;
        }

        $success = $messages[$notice][0];
        echo '<div class="notice ' . esc_attr($success ? 'notice-success' : 'notice-error') . ' is-dismissible"><p>' . esc_html($messages[$notice][1]) . '</p></div>';
    }

    /** Enforces WordPress capability checks before processing dashboard forms. */
    private static function require_admin() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to perform this action.', 'wp-awesome'));
        }
    }

    /** Redirects back to the connector page using a fixed, non-sensitive notice code. */
    private static function redirect_with_notice($notice) {
        $url = add_query_arg(
            array('page' => self::PAGE_SLUG, 'wpec_notice' => sanitize_key($notice)),
            admin_url('tools.php')
        );
        wp_safe_redirect($url);
        exit;
    }

    /** Converts a GitHub UTC timestamp to the WordPress site's local date and time. */
    private static function format_github_date($value) {
        $timestamp = is_string($value) ? strtotime($value) : false;
        return $timestamp ? wp_date(get_option('date_format') . ' ' . get_option('time_format'), $timestamp) : '—';
    }
}

register_activation_hook(__FILE__, array('WPEC_WordPress_Eleventy_Connector', 'activate'));
register_deactivation_hook(__FILE__, array('WPEC_WordPress_Eleventy_Lifecycle', 'deactivate'));
add_action('plugins_loaded', array('WPEC_WordPress_Eleventy_Connector', 'boot'));
