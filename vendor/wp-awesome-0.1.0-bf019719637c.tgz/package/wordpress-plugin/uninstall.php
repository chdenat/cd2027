<?php
/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: wordpress-plugin/uninstall.php
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

// WordPress sets this only for uninstall; direct requests must never erase data.
defined('WP_UNINSTALL_PLUGIN') || exit;

// Loading the publisher here would register hooks and could recreate the dropped schema.
require_once __DIR__ . '/lifecycle.php';

if (!WPEC_WordPress_Eleventy_Lifecycle::uninstall()) {
    wp_die(esc_html__('WP Awesome could not remove all of its data. Check the database and cron configuration, then retry deleting the plugin.', 'wp-awesome'));
}
