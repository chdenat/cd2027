/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: routes.d.ts
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

/** Public declarations for the routes subpath. */
export { assertNoWordPressRouteCollisions, createWordPressRouteResolver, resolveWordPressRoute, toOutputPath } from './index.js'
