<!--
 * This file is part of the wp-awesome package.
 *
 * File: CHANGELOG.md
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
-->

# Changelog

## 0.1.0 — unreleased

- Extract the standalone `wp-awesome` package and preserve its CommonJS API.
- Provide WordPress REST fetching, sanitization, Gutenberg conversion, record contracts, configurable routes, and optional Eleventy, WooCommerce, Yoast, and form integrations.
- Preserve safe image aspect ratios during HTML normalization, including square crops and authored portrait ratios.
- Include the optional WordPress publisher with a durable SQL outbox, cron retries, staging dispatch, and explicit production requests.
- Stop owned cron events on deactivation while retaining pending data; remove plugin-owned tables, options, and workflow caches on guarded uninstall across single-site and multisite installations.
- Add the Eleventy documentation site, an offline demo, Bun/Vite/Vitest tooling, clean-consumer checks, and npm/GitHub release automation.
