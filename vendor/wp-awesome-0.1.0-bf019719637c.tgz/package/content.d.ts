/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: content.d.ts
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

/** Public declarations for the content subpath. */
export { convertWordPressContent, parseSerializedContent, renderBlockTree, summarizeBlockTypes, unsupportedBlockNames } from './index.js'
