<!--
 * This file is part of the wp-awesome package.
 *
 * File: README.md
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
-->

# WP Awesome

**Keep writing in WordPress. Use that content to build your own website.**

WP Awesome connects WordPress to a static site built with Eleventy or another Node.js site builder. It retrieves the content you choose, prepares it for your templates, sanitizes its HTML, and resolves the public URLs you define. Your editors keep using WordPress while you control the website's design and hosting.

The optional WordPress plugin can request staging builds when public content changes and lets you inspect build results from WordPress. Your configured GitHub Actions workflow builds and deploys the site. The public package name is **`wp-awesome`**, without an organization scope.

Current source version: `0.1.0` (unreleased).

[Documentation source](docs-site/src/index.md) · [Installation and releases](docs-site/src/package-releases.md) · [Repository](https://github.com/chdenat/wp-awesome) · [npm package](https://www.npmjs.com/package/wp-awesome) · [MIT license](LICENSE.md)

The GitHub repository and Pages site are expected at `chdenat/wp-awesome`. The package is currently unreleased; preparing local files does not create the remote, publish to npm, or deploy documentation.

## Works with your WordPress tools

Use WP Awesome alongside **WooCommerce**, **Yoast SEO**, **Forminator**, and **MailPoet**. Its optional adapters fetch public WooCommerce products and categories, read URLs from Yoast compatible sitemaps, and let your site detect Forminator and MailPoet form references. The site you build supplies any required form rendering, submission, or transaction behavior.

Compatibility has been exercised on simple, single language WordPress sites. Multilingual setups have not been tested.

## Build with Web Awesome and Font Awesome

For the websites you build with WP Awesome, use **Web Awesome web components** and **Font Awesome icons** wherever practical. These are our preferred building blocks for interfaces: reuse existing components and icons to keep navigation, controls, and page layouts consistent. Your website chooses and loads the components and icon assets it needs.

## Work with an AI assistant

WP Awesome is **AI-ready**. We recommend using an AI coding assistant to help configure your WordPress content loader, build templates, and adapt the site to your needs. The repository includes written rules, task-specific skills, API documentation, and examples that give the assistant context for its work.

The [shared rules](.lgs1920/guidance/PROJECT_RULES.common.md) define the common baseline, while the [local package rules](PROJECT_RULES.md) add requirements specific to WP Awesome. You can extend that baseline with local rules in your own project's `PROJECT_RULES.md` and `AGENTS.md`, covering its routes, templates, UI choices, and deployment. These instructions guide both contributors and AI assistants.

Start by asking your assistant to read [AGENTS.md](AGENTS.md), follow the shared and local rules, and select the matching [package skill](skills/README.md) before making changes. Describe the result you want so it can work within your project's conventions.

## Install in a consumer

Node.js `>=22.12.0` is required. Consumers can use npm or Bun; Bun, PHP, Vite, and Vitest are development tools, rather than requirements for running the JavaScript library.

After the first npm release:

```sh
npm install wp-awesome@0.1.0
# Or:
bun add wp-awesome@0.1.0
```

After the GitHub repository and version tag exist:

```sh
npm install github:chdenat/wp-awesome#v0.1.0
# Or:
bun add github:chdenat/wp-awesome#v0.1.0
```

Use a version tag or commit rather than `main` for a reproducible consumer. GitHub dependencies keep the same `require('wp-awesome')` import. The CommonJS runtime and declarations are source files, so installation does not need a build lifecycle script.

Today, use a local checkout or an archive produced from it:

```sh
npm install /absolute/path/to/wp-awesome
# Or, from this repository:
bun pm pack --ignore-scripts --destination artifacts
# Then, from the consuming project:
npm install /absolute/path/to/wp-awesome/artifacts/wp-awesome-0.1.0.tgz
```

## Minimal usage

```js
const {
  createWordPressRestClient,
  createWordPressRouteResolver,
  normalizeWordPressRecord,
  assertNoWordPressRouteCollisions,
} = require('wp-awesome')

const rest = createWordPressRestClient({
  baseUrl: 'https://beautiful.wp.site/wp-json/',
})
const resolveRoute = createWordPressRouteResolver({
  siteUrl: 'https://www.beautiful.example',
  routes: { page: '/{slug}/' },
})

const loadPages = async () => {
  const source = await rest.getCollection('wp/v2/pages', {
    params: { status: 'publish', _embed: 1 },
    maxPages: 30,
  })
  const pages = source.map(record => normalizeWordPressRecord(record, {
    type: 'page',
    routeResolver: resolveRoute,
    contentPolicy: { mode: 'rendered' },
  }))
  assertNoWordPressRouteCollisions(pages)
  return pages
}
```

`beautiful.wp.site` is fictitious. Replace it before fetching. In a native ESM consumer, use `import wpAwesome from 'wp-awesome'`, then destructure the default CommonJS export. Optional integrations are separate subpaths: `wp-awesome/integrations/woocommerce`, `wp-awesome/integrations/yoast`, and `wp-awesome/integrations/forms`.

The package sanitizes retained HTML and copies custom fields only through an explicit allowlist. Consumers own record selection, public URL policy, templates, theme, redirects, cache, runtime transactions, and deployment. Read [architecture and limits](docs-site/src/under-the-hood.md) before replacing a live site.

## Develop and preview documentation

Install Bun `1.4.2`, Node.js `>=22.12.0`, PHP CLI `>=7.2`, and the `zip` CLI. From this repository:

```sh
bun install --frozen-lockfile
bun run verify
bun run docs:serve
```

The Eleventy documentation and offline demo use **http://localhost:4177**, without automatic port reassignment. Vite builds `docs-site/.vite/assets/docs.css`; Eleventy generates `docs-site/_site/`. No WordPress credentials or network requests are needed to build the guide. The isolated npm consumer check downloads the package's runtime dependencies.

| Command | Purpose and output |
| --- | --- |
| `bun run test` / `test:watch` | Deterministic Vitest runtime and security tests |
| `bun run test:php` | PHP syntax, durable outbox, and deactivation/uninstall tests for single-site and multisite |
| `bun run lint` | First-party JavaScript lint with warnings treated as failures |
| `bun run build` | Vite documentation stylesheet build |
| `bun run docs:build` / `docs:check` | Clean Eleventy build / generated links and fragments |
| `bun run docs:serve` | Build and serve the guide on fixed port 4177 |
| `bun run demo:build` / `demo:serve` | Documentation aliases including the real offline-normalization demo |
| `bun run test:package` | Install a real tarball in a temporary consumer; check all 11 exports, Node, Bun, ESM, types, and bundling |
| `bun run plugin:build` | Create `artifacts/wp-awesome-0.1.0.zip` for WordPress upload |
| `bun run pack:check` | Inspect publishable files without generating or publishing a tarball |
| `bun run verify` / `check` | Tests, lint, PHP, docs, clean consumer, plugin ZIP, and headers |
| `bun run publish:check` | Complete verification and package preview; no publication |
| `bun run headers:update` / `headers:update:all` / `headers:check` | Update staged/all source headers, or audit all headers |
| `bun run git:hooks:install` | Install local pre/post-commit guidance and header hooks |
| `bun run release:preview` | Print the proposed version and annotated-tag notes without mutations |
| `bun run release -- --initial` | Explicitly verify, commit version files, tag, and push the first release |

The header updater supports explicit file paths and preserves PHP opening tags, Nunjucks/Markdown front matter, shebangs, and comment syntax. `scripts/vendor-agent-links.mjs` materializes configured guidance links before a requested commit and restores them afterward; `.agent-links.json` declares those paths. The shared rules and local skills are already physical files for a self-contained checkout.

## WordPress plugin and publication

`wordpress-plugin/wp-awesome.php` is the optional publisher. Upload the ZIP generated by `bun run plugin:build` in **Plugins → Add New → Upload Plugin**, or copy all top-level PHP files from `wordpress-plugin/` into `wp-content/plugins/wp-awesome/`, then activate it. Configure its GitHub token, repository, and staging/production targets server-side. It captures public edits, writes a durable SQL outbox, dispatches staging builds, retries cron failures, and exposes explicit production requests. Keep only one publisher for the same content events. See the [plugin guide](docs-site/src/wp-awesome.md).

Deactivation stops the plugin's scheduled sends and preserves its queue/history. Deleting it through WordPress removes its own tables, options, workflow caches, and cron events, including multisite data; editorial and transaction records remain intact. Direct filesystem deletion does not run the guarded uninstall entry point.

The GitHub workflows follow the existing Timeline pattern: frozen Bun installation and verification, version-tag validation, npm authentication through `NPM_TOKEN`, skip already published versions, and an annotated-tag GitHub release. WP Awesome also attaches the JavaScript tarball and WordPress plugin ZIP. Configure the `npm` environment and GitHub Pages before using these workflows; see [package installation and releases](docs-site/src/package-releases.md).

## License

WP Awesome is released under the [MIT License](LICENSE.md).
