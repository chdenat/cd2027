/******************************************************************************
 * This file is part of the wp-awesome package.
 *
 * File: styles.d.ts
 *
 * Author: Christian Denat
 *
 * Created on: 2026-10-05
 * Last modified: 2026-10-05
 *
 * Copyright © 2026 Christian Denat
 ******************************************************************************/

/** Public declarations for the styles subpath. */
export { extractWordPressColorPalette, extractWordPressLinkColors, isSafeCssColorValue } from './index.js'
